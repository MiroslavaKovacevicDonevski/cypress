/// <reference types="cypress" />
const locators = require ("../../../fixtures/locators.json")

describe("login case", () => {
    beforeEach(() => {
        cy.visit("")
    })

    it("login failed- wrong email", () => {
        cy.get(locators.navigation.loginBtn).click()
        cy.get(locators.login.email).type("mira@mmmmailinator.com")
        cy.get(locators.login.password).type("A1234567")
        cy.get(locators.login.submitBtn).click()
        cy.get(locators.login.errorLogin).should("be.visible")
        cy.get(locators.login.errorLogin).should("have.text", "Bad Credentials")
        cy.get(locators.login.errorLogin).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("login failed- wrong pass", () => {
        cy.get(locators.navigation.loginBtn).click()
        cy.get(locators.login.email).type("mira@mailinator.com")
        cy.get(locators.login.password).type("A")
        cy.get(locators.login.submitBtn).click()
        cy.get(locators.login.errorLogin).should("be.visible")
        cy.get(locators.login.errorLogin).should("have.text", "Bad Credentials")
        cy.get(locators.login.errorLogin).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("successful login", () => {
        cy.get(locators.navigation.loginBtn).click()
        cy.get(locators.login.email).type("mira@mailinator.com")
        cy.get(locators.login.password).type("A1234567")
        cy.get(locators.login.submitBtn).click()
        cy.get(locators.navigation.registerBtn).should('not.exist')
        cy.get(locators.navigation.loginBtn).should('not.exist')
    })
})