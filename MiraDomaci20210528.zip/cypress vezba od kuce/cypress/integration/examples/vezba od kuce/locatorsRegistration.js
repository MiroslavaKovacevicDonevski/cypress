/// <reference types="cypress" />
const locators = require ("../../../fixtures/locators.json")
const faker = require('faker');

describe("register new user", () => {
    beforeEach(() => {
        cy.visit("")
        
    })
    
    it("1. registracion failed- email already exists", () => {
        cy.get(locators.navigation.registerBtn).click()
        cy.get(locators.registerNewUser.firstName).type("moje ime")
        cy.get(locators.registerNewUser.lastName).type("moje prezime")
        cy.get(locators.registerNewUser.email).type("mira@mailinator.com")
        cy.get(locators.registerNewUser.password).type("12345678")
        cy.get(locators.registerNewUser.confirmedPass).type("12345678")
        cy.get(locators.registerNewUser.termsCheck).check()
        cy.get(locators.registerNewUser.submitBtn).click()
        cy.get(locators.registerNewUser.errorEmail).should('be.visible')
        cy.get(locators.registerNewUser.errorEmail).should("have.text", "The email has already been taken.")
        cy.get(locators.registerNewUser.errorEmail).should("have.css", "background-color", "rgb(248, 215, 218)")

        cy.intercept({url: "/api/auth/register", method: "POST"}, {success: true}).as("status 422")
   })

   it("2. registracion failed- email has wrong format", () => {
        cy.get(locators.navigation.registerBtn).click()
        cy.get(locators.registerNewUser.firstName).type("moje ime")
        cy.get(locators.registerNewUser.lastName).type("moje prezime")
        cy.get(locators.registerNewUser.email).type("mira5556@mailinator")
        cy.get(locators.registerNewUser.password).type("12345678")
        cy.get(locators.registerNewUser.confirmedPass).type("12345678")
        cy.get(locators.registerNewUser.termsCheck).check()
        cy.get(locators.registerNewUser.submitBtn).click()
        cy.get(locators.registerNewUser.errorEmail).should('be.visible')
        cy.get(locators.registerNewUser.errorEmail).should("have.text", "The email must be a valid email address.")
        cy.get(locators.registerNewUser.errorEmail).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("3. registracion failed- pass and confirm does not match", () => {
        cy.get(locators.navigation.registerBtn).click()
        cy.get(locators.registerNewUser.firstName).type("moje ime")
        cy.get(locators.registerNewUser.lastName).type("moje prezime")
        cy.get(locators.registerNewUser.email).type("miraneki111@mailinator.com")
        cy.get(locators.registerNewUser.password).type("12345678")
        cy.get(locators.registerNewUser.confirmedPass).type("1")
        cy.get(locators.registerNewUser.termsCheck).check()
        cy.get(locators.registerNewUser.submitBtn).click()
        cy.get(locators.registerNewUser.errorPassword).should('be.visible')
        cy.get(locators.registerNewUser.errorPassword).should("have.text", "The password confirmation does not match.")
        cy.get(locators.registerNewUser.errorPassword).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("4. registracion failed- pass has less then 8 characters", () => {
        cy.get(locators.navigation.registerBtn).click()
        cy.get(locators.registerNewUser.firstName).type("moje ime")
        cy.get(locators.registerNewUser.lastName).type("moje prezime")
        cy.get(locators.registerNewUser.email).type("miraneki111@mailinator.com")
        cy.get(locators.registerNewUser.password).type("1")
        cy.get(locators.registerNewUser.confirmedPass).type("1")
        cy.get(locators.registerNewUser.termsCheck).check()
        cy.get(locators.registerNewUser.submitBtn).click()
        cy.get(locators.registerNewUser.errorPassword).should('be.visible')
        cy.get(locators.registerNewUser.errorPassword).should("have.text", "The password must be at least 8 characters.")
        cy.get(locators.registerNewUser.errorPassword).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("5. registracion failed- the terms are uncheck", () => {
        cy.get(locators.navigation.registerBtn).click()
        cy.get(locators.registerNewUser.firstName).type("moje ime")
        cy.get(locators.registerNewUser.lastName).type("moje prezime")
        cy.get(locators.registerNewUser.email).type("miraneki111@mailinator.com")
        cy.get(locators.registerNewUser.password).type("12345678")
        cy.get(locators.registerNewUser.confirmedPass).type("12345678")
        cy.get(locators.registerNewUser.termsCheck).uncheck()
        cy.get(locators.registerNewUser.submitBtn).click()
        cy.get(locators.registerNewUser.errorTerms).should('be.visible')
        cy.get(locators.registerNewUser.errorTerms).should("have.text", "The terms and conditions must be accepted.")
        cy.get(locators.registerNewUser.errorTerms).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("successful registration", () => {
        cy.get(locators.navigation.registerBtn).click()
        cy.get(locators.registerNewUser.h1Register).should('have.text',"Register")
        cy.get(locators.registerNewUser.firstName).type("moje ime")
        cy.get(locators.registerNewUser.lastName).type("moje prezime")
        cy.get(locators.registerNewUser.email).type(faker.internet.email())
        cy.get(locators.registerNewUser.password).type("12345678")
        cy.get(locators.registerNewUser.confirmedPass).type("12345678")
        cy.get(locators.registerNewUser.termsCheck).check()
        cy.get(locators.registerNewUser.submitBtn).click()

        cy.intercept({url: "/api/auth/register", method: "POST"}, {success: true}).as("status 200")
        cy.intercept({url: "/api/galleries?page=1&term=", method: "GET"}, {success: true}).as("status 200")
        
        
    })

})