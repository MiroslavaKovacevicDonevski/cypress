/// <reference types="cypress" />
const locators = require ("../../../fixtures/locators.json")

describe("create gall case", () => {
    beforeEach(() => {
        cy.visit("")
        cy.get(locators.navigation.loginBtn).click()
        cy.get(locators.login.email).type("mira@mailinator.com")
        cy.get(locators.login.password).type("A1234567")
        cy.get(locators.login.submitBtn).click()
    })
    
    
    var a ="b"
    it("1. create a new gallery with 256 characters in title", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type(a.repeat(256))
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorTitle).should("be.visible")
        cy.get(locators.createNewGallery.errorTitle).should("have.text", "The title may not be greater than 255 characters.")
        cy.get(locators.createNewGallery.errorTitle).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("2. create a new gallery with 1 character in title", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("a")
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorTitle).should("be.visible")
        cy.get(locators.createNewGallery.errorTitle).should("have.text", "The title must be at least 2 characters.")
        cy.get(locators.createNewGallery.errorTitle).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("3. create a new gallery with 1001 characters in description", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("Ime galerije")
        cy.get(locators.createNewGallery.gallDescription).type(a.repeat(1001))
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorDescription).should("be.visible")
        cy.get(locators.createNewGallery.errorDescription).should("have.text", "The description may not be greater than 1000 characters.")
        cy.get(locators.createNewGallery.errorDescription).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("4. create a new gallery with wrong img format", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("Ime galerije")
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.gif")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorImage).should("be.visible")
        cy.get(locators.createNewGallery.errorImage).should("have.text", "The description may not be greater than 1000 characters.")
        cy.get(locators.createNewGallery.errorImage).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("create a new gallery", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("galerija za brisanje")
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
    })

    it("delete gallery", () => {
        cy.get(locators.galleryNavigations.openMyFirstGallery).click()
        cy.get(locators.galleryNavigations.deleteBtn).click()
    })

})