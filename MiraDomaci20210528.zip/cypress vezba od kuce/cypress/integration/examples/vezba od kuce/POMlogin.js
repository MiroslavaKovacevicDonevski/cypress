/// <reference types="cypress" />
import {authLogin} from "../../../pageObject/authLoginPage"
const faker = require('faker')

describe("login user in application", () => {
    beforeEach(() => {
        cy.visit("")
        authLogin.clickLoginBtn()
    })

    it("1. login failed- email do not exists", () => {
        authLogin.loginInApp("mira.nsns@mailinator.com", "A1234567")
        authLogin.ErrorMsn()
    })

    it("2. login failed- email has wrong format", () => {
        authLogin.loginInApp("mira@mailinator", "A1234567")
        authLogin.ErrorMsn()
     })
    
    it("3. login failed- pass is wrong", () => {
        authLogin.loginInApp("mira@mailinator.com", "A123456a")
        authLogin.ErrorMsn()
    })

    it("login with valid credentials", () => {
        authLogin.loginInApp("mira@mailinator.com", "A1234567")
    })
})