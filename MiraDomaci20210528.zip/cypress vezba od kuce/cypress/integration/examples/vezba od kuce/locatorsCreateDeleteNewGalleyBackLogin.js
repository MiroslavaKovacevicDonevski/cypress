/// <reference types="cypress" />
const locators = require ("../../../fixtures/locators.json")

describe("create gall case", () => {
    beforeEach(() => {
        cy.loginTroughBackend("userName", "password")
        cy.visit("")
        cy.get(locators.navigation.loginBtn).should('not.exist')
    })

    
    var a ="b"
    it("1. create a new gallery with 256 characters in title", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type(a.repeat(256))
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorTitle).should("be.visible")
        cy.get(locators.createNewGallery.errorTitle).should("have.text", "The title may not be greater than 255 characters.")
        cy.get(locators.createNewGallery.errorTitle).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("2. create a new gallery with 1 character in title", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("a")
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorTitle).should("be.visible")
        cy.get(locators.createNewGallery.errorTitle).should("have.text", "The title must be at least 2 characters.")
        cy.get(locators.createNewGallery.errorTitle).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("3. create a new gallery with 1001 characters in description", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("Ime galerije")
        cy.get(locators.createNewGallery.gallDescription).type(a.repeat(1001))
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorDescription).should("be.visible")
        cy.get(locators.createNewGallery.errorDescription).should("have.text", "The description may not be greater than 1000 characters.")
        cy.get(locators.createNewGallery.errorDescription).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("4. create a new gallery with wrong img format", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("Ime galerije")
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.gif")
        cy.get(locators.createNewGallery.submitBtn).click()
        cy.get(locators.createNewGallery.errorImage).should("be.visible")
        cy.get(locators.createNewGallery.errorImage).should("have.text", "The description may not be greater than 1000 characters.")
        cy.get(locators.createNewGallery.errorImage).should("have.css", "background-color", "rgb(248, 215, 218)")
    })

    it("create a new gallery", () => {
        cy.get(locators.navigation.createGalleryBtn).click()
        cy.get(locators.createNewGallery.gallTitle).type("galerija za brisanje")
        cy.get(locators.createNewGallery.gallDescription).type("opis galerije")
        cy.get(locators.createNewGallery.gallImages).type("https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        cy.get(locators.createNewGallery.submitBtn).click()
    })

    it("delete gallery", () => {
        cy.visit("/my-galleries")
        cy.get(locators.galleryNavigations.openMyFirstGallery).click()
        cy.get(locators.galleryNavigations.deleteBtn).should('exist')
    // GRESKA: kao da ne vidi dugme Delete, samo u slučaju logina u pozadini
    //     cy.get(locators.galleryNavigations.deleteBtn).click()
    })

})