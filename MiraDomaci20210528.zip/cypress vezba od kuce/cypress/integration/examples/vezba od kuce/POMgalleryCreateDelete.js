/// <reference types="cypress" />
import {authLogin} from "../../../pageObject/authLoginPage"
import {galleryCreate} from "../../../pageObject/galleryCreateDeletePage.js"
const faker = require('faker')

describe("create a new gallery in application", () => {
    beforeEach(() => {
        cy.visit("")
        authLogin.clickLoginBtn()
        authLogin.loginInApp("mira@mailinator.com", "A1234567")
        //authLogin.clickCreateGalleryBtn().should('be.disable')
        galleryCreate.clickCreateGalleryBtn()
        //galleryCreate.galleryTitle().should("be.there")
    })

    var a = "b"
    it("1. create a new gallery with 256 characters in title", () => {
        galleryCreate.createGallInApp(a.repeat(256), "opis", "https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        //The title may not be greater than 255 characters.
    })

    it("2. create a new gallery with 1 character in title", () => {
        galleryCreate.createGallInApp("1", "opis", "https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        //The title must be at least 2 characters.
     })
    
    it("3. create a new gallery with 1001 characters in description", () => {
        galleryCreate.createGallInApp("Ime galerije", a.repeat(1001), "https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
        //The description may not be greater than 1000 characters.
    })

    it("4. create a new gallery with wrong img format", () => {
        galleryCreate.createGallInApp("Ime galerije", "opis", "https://www.freedigitalphotos.net/images/img/homepage/87357.gif")
        //Wrong format of image
    })

    it("create a new gallery", () => {
        galleryCreate.createGallInApp("Nova galerija za brisanje", "Opis je nebitan", "https://www.freedigitalphotos.net/images/img/homepage/87357.jpg")
    })

    it("delete gallery", () => {
        cy.visit("/my-galleries")
        galleryCreate.openFirstGallery()
        galleryCreate.clickDeleteGalleryBtn()
    })
})