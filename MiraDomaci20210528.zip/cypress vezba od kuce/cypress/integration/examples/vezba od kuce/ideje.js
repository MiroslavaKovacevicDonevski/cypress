// npr kod logina:
// //nakon uspesog logovanja dugme Login i Register ne treba da se vide
// cy.get(locators.navigation.registerBtn).should('not.exist')
// cy.get(locators.navigation.loginBtn).should('not.exist')


//url za sliku: https://images.freeimages.com/images/small-previews/157/young-and-old-1399297.jpg
// https://www.freedigitalphotos.net/images/img/homepage/87357.jpg

//.............

//To res.send(), to stub a response from a response handler: res.send(staticResponse)

// const staticResponse = {
//     /* some StaticResponse properties here... */
//   }
  
//   cy.intercept('/projects', staticResponse)

//.............

// cy.intercept('/not-found', {
//     statusCode: 404,
//     body: '404 Not Found!',
//     headers: {
//       'x-not-found': 'true',
//     },
//   })