/// <reference types="cypress" />
import {registerNewUser} from "../../../pageObject/registerPage.js"
const faker = require('faker')

describe("register a new user in application", () => {
    beforeEach(() => {
        cy.visit("")
        registerNewUser.clickRegisterBtn()
    })

    it("1. registracion failed- email already exists", () => {
        registerNewUser.registerInApp("Mira", "Mirak", "mira.ns.72@gmail.com", "12345678", "12345678")
        registerNewUser.errorEmailTaken()
    })

    it("2. registracion failed- email has wrong format", () => {
        registerNewUser.registerInApp("Mira", "Mirak", "mira.ns.72@gmail", "12345678", "12345678")
        registerNewUser.errorEmailFormat()
    })

    it("3. registracion failed- pass and confirm does not match", () => {
        registerNewUser.registerInApp("Mira", "Mirak", faker.internet.email(), "12345678", "1")
        registerNewUser.errorPasswordMatch()
    })

    it("4. registracion failed- pass has less then 8 characters", () => {
        registerNewUser.registerInApp("Mira", "Mirak", faker.internet.email(), "1234567", "1234567")
        registerNewUser.errorPasswordLength()
    })

    it("5. registracion failed- the terms are uncheck", () => {
        registerNewUser.registerInAppMissingTerms("Mira", "Mirak", faker.internet.email(), "12345678", "12345678")
        registerNewUser.errorTermsUncheck()
    })

    it("register with valid credentials", () => {
        registerNewUser.registerInApp("Mira", "Mirak", faker.internet.email(), "12345678", "12345678")
       })
})