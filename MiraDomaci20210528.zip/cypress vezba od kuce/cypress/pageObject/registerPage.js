class RegisterNewUser  {

    get registerBtn() {
        return cy.get(":nth-child(2) > .nav-link")
    }

    clickRegisterBtn() {
        this.registerBtn.click()
    }

    get firstName() {
        return cy.get("input#first-name")
    }

    get lastName() {
        return cy.get("input#last-name")
    }

    get email() {
        return cy.get("input#email")
    }

    get password() {
        return cy.get("input#password")
    }
    
    get confirmedPassword() {
        return cy.get("input#password-confirmation")
    }

    get terms() {
        return cy.get(".form-check-input")
    }

    get submitBtn() {
        return cy.get("form > .btn.btn-custom")
    }

    get h1Register() {
        return cy.get(".title-style")
    }

    get errorEmail() {
        return cy.get(":nth-child(3) > .alert")
    }

    errorEmailTaken() {
        this.errorEmail.should("be.visible")
        this.errorEmail.should("have.css", "background-color", "rgb(248, 215, 218)")
        this.errorEmail.should("have.text", "The email has already been taken.")
    }

    errorEmailFormat() {
        this.errorEmail.should("be.visible")
        this.errorEmail.should("have.css", "background-color", "rgb(248, 215, 218)")
        this.errorEmail.should("have.text", "The email must be a valid email address.")
    }

    get errorPassword() {
        return cy.get("div:nth-of-type(4) > .alert.alert-danger")
    }

    errorPasswordMatch() {
        this.errorPassword.should("be.visible")
        this.errorPassword.should("have.css", "background-color", "rgb(248, 215, 218)")
        this.errorPassword.should("have.text", "The password confirmation does not match.")
    }

    
    errorPasswordLength() {
        this.errorPassword.should("be.visible")
        this.errorPassword.should("have.css", "background-color", "rgb(248, 215, 218)")
        this.errorPassword.should("have.text", "The password must be at least 8 characters.")
    }

    get errorTerms() {
        return cy.get("div:nth-of-type(6) > .alert.alert-danger")
    }

    errorTermsUncheck() {
        this.errorTerms.should("be.visible")
        this.errorTerms.should("have.css", "background-color", "rgb(248, 215, 218)")
        this.errorTerms.should("have.text", "The terms and conditions must be accepted.")
    }

    registerInApp(firstName, lastName,email, password, confirmedPassword) {
        this.firstName.type(firstName)
        this.lastName.type(lastName)
        this.email.type(email)
        this.password.type(password)
        this.confirmedPassword.type(confirmedPassword)
        this.terms.check()
        this.submitBtn.click()
    }

    registerInAppMissingTerms(firstName, lastName,email, password, confirmedPassword) {
        this.firstName.type(firstName)
        this.lastName.type(lastName)
        this.email.type(email)
        this.password.type(password)
        this.confirmedPassword.type(confirmedPassword)
        this.terms.uncheck()
        this.submitBtn.click()
    }
}
export const registerNewUser = new RegisterNewUser