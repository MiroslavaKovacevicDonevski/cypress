class ANewGalleryCreate  {

    get createGalleryBtn() {
        return cy.get(".mr-auto > :nth-child(3) > .nav-link")
    }

    clickCreateGalleryBtn() {
        this.createGalleryBtn.click()
    }

    get galleryTitle() {
        return cy.get("input#title")
    }

    get galleryDescription() {
        return cy.get("input#description")
    }

    get galleryImage() {
        return cy.get(".input-group.mb-3 > .form-control")
    }

    get addNewImageBtn() {
        return cy.get("form div:nth-of-type(3) > [type]")
    }

    clickAddNewImageBtn() {
        this.addNewImageBtn.click()
    }

    get submitBtn() {
        return cy.get("form > button:nth-of-type(1)")
    }

    get FirstGallery() {
        return cy.get(":nth-child(1) > h2 > .box-title")
    }

    openFirstGallery() {
        this.FirstGallery.click()
    }

    get deleteGalleryBtn() {
        return cy.get(":nth-child(5) > button.btn")
    }
    
    clickDeleteGalleryBtn() {
        this.deleteGalleryBtn.click()
    }
    

    createGallInApp(galleryTitle, galleryDescription, galleryImage) {
        this.galleryTitle.type(galleryTitle)
        this.galleryDescription.type(galleryDescription)
        this.galleryImage.type(galleryImage)
        this.submitBtn.click()
    }
}
export const galleryCreate = new ANewGalleryCreate