class AuthLogin  {

    get loginBtn() {
        return cy.get("a[href='/login']")
    }

    clickLoginBtn() {
        this.loginBtn.click()
    }

    get email() {
        return cy.get("input#email")
    }

    get password() {
        return cy.get("input#password")
    }

    get submitBtn() {
        return cy.get("form > .btn.btn-custom")
    }

    get error() {
        return cy.get("form > .alert.alert-danger")
    }

    ErrorMsn() {
        this.error.should("be.visible")
        this.error.should("have.text", "Bad Credentials")
        this.error.should("have.css", "background-color", "rgb(248, 215, 218)")
    }


    loginInApp(email, password) {
        this.email.type(email)
        this.password.type(password)
        this.submitBtn.click()
    }
}
export const authLogin = new AuthLogin