const locator = require("../../fixtures/locator.json")
const faker = require("faker");

let userData = {
    randomName: faker.name.findName(),
    randomLastName: faker.name.lastName(),
    randomEmail: faker.internet.email(),
    randomPassword: faker.internet.password()
}

describe('login case', () => {
    beforeEach( () => {
        cy.visit('')
        cy.get(locator.navigation.loginButton).click()
    })

    it("negative login- bad email", () => {
        cy.get(locator.loginPage.email).type(faker.internet.email())
        cy.get(locator.loginPage.password).type(faker.internet.password())
        cy.get(locator.loginPage.submitBtn).click()
    })

    it("negative login- no @", () => {
        cy.get(locator.loginPage.email).type('mira.ns.72gmail.com')
        cy.get(locator.loginPage.password).type('xxxxxxx77')
        cy.get(locator.loginPage.submitBtn).click()
    })
    
    it("negative login- bad pass", () => {
        cy.get(locator.loginPage.email).type('mira.ns.72@gmail.com')
        cy.get(locator.loginPage.password).type('xxxxxxx777')
        cy.get(locator.loginPage.submitBtn).click()
    })

    it('login with valid credentials', () => {
        cy.get(locator.loginPage.email).type('mira.ns.72@gmail.com')
        cy.get(locator.loginPage.password).type('xxxxxxx77')
        cy.get(locator.loginPage.submitBtn).click()
        cy.get(locator.navigation.logoutButton).click()
    })
    
})