const locator = require("../../fixtures/locator.json")

describe('register', () => {
    beforeEach('visit gallery app', () => {
        cy.visit('')
        cy.get(':nth-child(2) > .nav-link').eq(0).click();
    })

    it('empty name', () => {
        cy.get(locator.register.firstName).type(' ')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('xxxxxxx77')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })
    
    it('empty lastName', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type(' ')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('xxxxxxxMira77')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('empty email', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type(' ')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('xxxxxxx77')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('email dosn`t have @', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72gmail.com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('xxxxxxx77')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('email has two dots', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail..com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('xxxxxxx77')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('empty pass', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type(' ')
        cy.get(locator.register.passwordConirm).type('xxxxxxx77')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('pass&confirm has one caracter', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type('1')
        cy.get(locator.register.passwordConirm).type('1')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('pass&confirm are not same', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('1')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('empty confirmPass', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type(' ')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })

    it('terms is not check', () => {
        cy.get(locator.register.firstName).type('Mira')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('xxxxxxx77')
        cy.get(locator.register.terms).uncheck()
        cy.get(locator.register.submit).click()
    })

    it('OK register', () => {
        cy.get(locator.register.firstName).type('Miroslava')
        cy.get(locator.register.lastName).type('KD')
        cy.get(locator.register.email).type('mira.ns.72@gmail.com')
        cy.get(locator.register.password).type('xxxxxxx77')
        cy.get(locator.register.passwordConirm).type('xxxxxxx77')
        cy.get(locator.register.terms).check()
        cy.get(locator.register.submit).click()
    })
    
})