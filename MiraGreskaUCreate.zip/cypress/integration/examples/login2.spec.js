

import { authLogin } from "../../pageObjects/loginPage.js"


describe('login case', () => {
    beforeEach(() => {
        cy.visit('')
        authLogin.clickLoginButton()
    })


    it('login with valid credentials', () => {
        authLogin.login('mira.ns.72@gmail.com','xxxxxxx77')
    })
    
})