

import { createGall } from "../pageObjects/createGallPage.js"
import { authLogin } from "../pageObjects/loginPage.js"


describe('createGallery', () => {
    before('visit gallery app', () => {
        cy.visit('')
        authLogin.clickLoginButton()

        it('login with valid credentials', () => {
            authLogin.login('mira.ns.72@gmail.com','xxxxxxx77')
        })

    })

    it("open gallery", () => {
        createGall.clickCreateGalleryBtn()

    })

    it('create gallery', () => {
        createGall.create('Moja galerija','Opis je lep', 'https://tinypng.com/images/social/website.jpg')
    })
})