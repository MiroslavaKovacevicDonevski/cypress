
class CreateGall {
    
    get title() {
        return cy.get("input[id='title']")
    }

    get description() {
        return cy.get("input[id='description']")
    }

    get images() {
        return cy.get("input[type='url']")
    }

    get addImages() {
        return cy.get("button[type='button']")
    }

    clickAddImage() {
        this.addImages.click()
    }

    get SubmitBtn() {
        return cy.get("button[type='submit']")
    }

    get createGalleryBtn() {
        return cy.get('a[href="/create"]')
    }

    clickCreateGalleryBtn() {
        this.createGalleryBtn.click()
    }
    
    create(title, description, images) {
        this.title.type(title)
        this.description.type(description)
        this.images.type(url)
        this.SubmitBtn.click()
    }

}

export const createGall = new CreateGall()